package problem1;


public class MyThread extends Thread{ //By extending thread class
	public void run() {
		System.out.println("Active Thread name ="+Thread.currentThread().getName());
		System.out.println("Active Thread priority ="+Thread.currentThread().getPriority());
	}
 public static void main(String a[])
 {
	 MyThread mtp1=new MyThread();
	 MyThread mtp2=new MyThread();
	 
	 mtp1.setPriority(Thread.MIN_PRIORITY);
	 mtp2.setPriority(Thread.MAX_PRIORITY);
	 mtp1.start();
	 mtp2.start();
	 
 }
}



