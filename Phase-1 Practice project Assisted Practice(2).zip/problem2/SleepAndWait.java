package problem2;

public class SleepAndWait {
	  
    public static void main(String[] args) throws InterruptedException {
      
        
        System.out.println("Sleeping for 3 seconds...");
        Thread.sleep(3000);
        System.out.println("Ready to run after sleeping for 3 seconds");
        
       
        final SharedObject sharedObj = new SharedObject();
        
       
        Thread thread1 = new Thread(new Runnable() {
            public void run() {
                try {
                    sharedObj.waitMethod();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            public void run() {
                sharedObj.notifyMethod();
            }
        });
        thread1.start();
        thread2.start();
    }
}

class SharedObject {
  
    synchronized void waitMethod() throws InterruptedException {
        System.out.println("Thread 1 is waiting...");
        wait();
        System.out.println("Thread 1 is notified");
    }
  
    synchronized void notifyMethod() {
        System.out.println("Thread 2 is notifying Thread 1");
        notify()
        		;}
}
        		
        		
        		