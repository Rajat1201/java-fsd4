package problem3;

public class Syncronization {

    public static void main(String[] args) {

        SharedResource sharedResource = new SharedResource();

        Thread thread1 = new Thread(new MyRunnable(sharedResource, "Thread 1"));
        Thread thread2 = new Thread(new MyRunnable(sharedResource, "Thread 2"));

        thread1.start();
        thread2.start();
    }
}

class SharedResource {
    private int count = 0;

    public synchronized void increment() {
        count++;
        System.out.println("Count is now on"+count + " in " + Thread.currentThread().getName());
    }
}

class MyRunnable implements Runnable {

    private final SharedResource sharedResource;
    private final String threadName;

    public MyRunnable(SharedResource sharedResource, String threadName) {
        this.sharedResource = sharedResource;
        this.threadName = threadName;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            sharedResource.increment();}}}
        
    
    
    
    
    
    
    
   
        
    
    
    
        
    
    
    
    
    
    
    
 