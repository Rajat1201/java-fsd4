package problem5;

import java.io.*;

class MyException extends Exception {
  public MyException(String errorMessage) {
    super(errorMessage);
  }
}

class MyClass {
  public void readFile() throws IOException {
    BufferedReader reader = new BufferedReader(new FileReader("Myfile.txt"));
    //Tester please enter your file path here
    try {
      String line = reader.readLine();
      while (line != null) {
        System.out.println(line);
        line = reader.readLine();
      }
    } catch (IOException e) {
      throw e;
    } finally {
      reader.close();
      System.out.println("File closed");
    }
  }

  public void myMethod() throws MyException {
    int x = 5;
    if (x < 10) {
      throw new MyException("x is too small");
    }
  }
}

public class Main {
  public static void main(String[] args) {
    MyClass obj = new MyClass();
    try {
      obj.readFile();
    } catch (IOException e) {
      System.out.println("Error reading file: " + e.getMessage());
    } finally {
      System.out.println("Finally block executed");
    }

    try {
      obj.myMethod();
    } catch (MyException e) {
      System.out.println("Custom exception: " + e.getMessage());
      
    }
 
}}