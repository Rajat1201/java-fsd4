package problem6;

public class ExceptionHandling {

	public static void main(String[] a) {
	System.out.println("Program starts here");
	try {
		int arr[]= {20,30,40,50};
		System.out.println(arr[10]);
		String str=null;
		System.out.println(str.length());
	}
	catch(ArithmeticException e){
		System.out.println("Denomenator should not be zero ");
		System.out.println("Error:"+e);
		
	}
    catch(ArrayIndexOutOfBoundsException e){
    	System.out.println("User is trying to accessing array beyound limit ");
		System.out.println("Error:"+e);
		
	}
    catch(NullPointerException e){
    	System.out.println("user is trying to perform operation on null value ");
		System.out.println("Error:"+e);
		
	}
	finally {
		System.out.println("this block always execute");
	}
	System.out.println("Program ends here");
}}