package problem7;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class FileOperation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter file path: ");
        String filePath = scanner.nextLine();
        File file = new File(filePath);

        try {
            if (!file.exists()) {
                boolean created = file.createNewFile();
                if (created) {
                    System.out.println("File created");
                } else {
                    System.out.println("File creation failed.");
                }
            }

            System.out.println("1-Create, 2-Read, 3-Update, 4-Delete: ");
            int operation = scanner.nextInt();

            switch (operation) {
                case 1:
                    System.out.println("Enter text to write: ");
                    scanner.nextLine();
                    String textToWrite = scanner.nextLine();
                    FileOperation.writeToFile(file, textToWrite);
                    break;
                case 2:
                    String content = FileOperation.readFromFile(file);
                    System.out.println("File content:\n" + content);
                    break;
                case 3:
                    System.out.println("Enter text to append: ");
                    scanner.nextLine();
                    String textToAppend = scanner.nextLine();
                    FileOperation.appendToFile(file, textToAppend);
                    break;
                case 4:
                    boolean deleted = file.delete();
                    if (deleted) {
                        System.out.println("File deleted");
                    } else {
                        System.out.println("File deletion failed.");
                    }
                    break;
                default:
                    System.out.println("Invalid operation.");
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    private static String readFromFile(File file) throws IOException {
        Scanner scanner = new Scanner(file);
        StringBuilder sb = new StringBuilder();
        while (scanner.hasNextLine()) {
            sb.append(scanner.nextLine());
            sb.append("\n");
        }
        scanner.close();
        return sb.toString();
    }

    private static void writeToFile(File file, String text) throws IOException {
        java.io.FileWriter writer = new java.io.FileWriter(file);
        writer.write(text);
        writer.close();
        System.out.println("Write operation successful!");
    }

    private static void appendToFile(File file, String text) throws IOException {
        java.io.FileWriter writer = new java.io.FileWriter(file, true);
        writer.write(text);
        writer.close();
        System.out.println("Append operation successful!");
}}