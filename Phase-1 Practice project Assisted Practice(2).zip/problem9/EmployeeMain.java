package problem9;

interface Employee {
 String getName();
 String getDepartment();
 double getSalary();
}


interface Manager extends Employee {
 String getTeam();
}


interface SalesPerson extends Employee {
 double getCommission();
}


class ManagerImpl implements Manager {
 private String name;
 private String department;
 private double salary;
 private String team;

 public ManagerImpl(String name, String department, double salary, String team) {
     this.name = name;
     this.department = department;
     this.salary = salary;
     this.team = team;
 }

 public String getName() {
     return name;
 }

 public String getDepartment() {
     return department;
 }

 public double getSalary() {
     return salary;
 }

 public String getTeam() {
     return team;
 }
}


class SalesPersonImpl implements SalesPerson {
 private String name;
 private String department;
 private double salary;
 private double commission;

 public SalesPersonImpl(String name, String department, double salary, double commission) {
     this.name = name;
     this.department = department;
     this.salary = salary;
     this.commission = commission;
 }

 public String getName() {
     return name;
 }

 public String getDepartment() {
     return department;
 }

 public double getSalary() {
     return salary;
 }

 public double getCommission() {
     return commission;
 }
}


class ManagerSalesPerson implements Manager, SalesPerson {
 private String name;
 private String department;
 private double salary;
 private String team;
 private double commission;

 public ManagerSalesPerson(String name, String department, double salary, String team, double commission) {
     this.name = name;
     this.department = department;
     this.salary = salary;
     this.team = team;
     this.commission = commission;
 }

 public String getName() {
     return name;
 }

 public String getDepartment() {
     return department;
 }

 public double getSalary() {
     return salary;
 }

 public String getTeam() {
     return team;
 }

 public double getCommission() {
     return commission;
 }
}

public class EmployeeMain {
 public static void main(String[] args) {
     ManagerImpl manager = new ManagerImpl("Vivek Sharma", "Sales", 40000, "Marketing");
     SalesPersonImpl salesPerson = new SalesPersonImpl("Rohit Sharma", "Sales", 50000, 90000);
     ManagerSalesPerson managerSalesPerson = new ManagerSalesPerson("Raina", "Sales", 60000, "Marketing", 45000);

     
     System.out.println("Manager:");
     System.out.println("Name: " + manager.getName());
     System.out.println("Department: " + manager.getDepartment());
     System.out.println("Salary: " + manager.getSalary());
     System.out.println("Team: " + manager.getTeam());

     System.out.println("\nSales Person:");
     System.out.println("Name: " + salesPerson.getName());
     System.out.println("Department: " + salesPerson.getDepartment());
     System.out.println("Salary: " + salesPerson.getSalary());
     System.out.println("Commission: " + salesPerson.getCommission());

     System.out.println("\nManager/Sales Person");}}